<script>
  import Message from "$lib/components/Message.svelte";
</script>

<Message />